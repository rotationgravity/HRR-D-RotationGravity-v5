
import numpy as np
from scipy.optimize import curve_fit

# Modell
def z_model(r, A, gamma):
    return A * r**gamma

# Data
data = np.genfromtxt("union2.1_real_sample.csv", delimiter=",", names=True)
r = data["r_m"]
z_obs = data["z"]

# Fit
popt, _ = curve_fit(z_model, r, z_obs)
z_pred = z_model(r, *popt)

# Chi-squared
residuals = z_obs - z_pred
chi2 = np.sum((residuals)**2 / z_pred)
dof = len(z_obs) - len(popt)
chi2_red = chi2 / dof

print(f"Chi²_red: {chi2_red:.3f}")
