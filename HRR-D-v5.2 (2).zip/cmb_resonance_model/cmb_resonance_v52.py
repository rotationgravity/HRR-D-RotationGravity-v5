# HRR-D v5.2 – CMB resonansmodell
# Spiralbaserade vågmodeller för att återskapa multipoltopp vid l ≈ 220