# HRR-D v5.2 – Gravitationslinsning
# Beräkning av Einsteinradier och avböjning utan mörk materia