# HRR-D v5.2 – Supernova redshift-magnitude fit
# Rödförskjutning: z(r) = (1 - ω(r)^2 r^2)^(-1/2) - 1
# Jämförs mot Union2.1 / Pantheon+ dataset