import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# HRR-D v5.2: spiral geodet with dt dθ component and damped omega
omega0 = 1e-18
alpha = 1e-26

def omega(r):
    return omega0 * np.exp(-alpha * r)

def domega_dr(r):
    return -alpha * omega(r)

def geodesic_eq(lambda_, y):
    t, r, theta, t_dot, r_dot, theta_dot = y

    ω = omega(r)
    dω = domega_dr(r)

    dt_ddλ = -2 * ω * r * theta_dot * r_dot - 2 * ω * r * t_dot * theta_dot - r**2 * dω * theta_dot**2
    dr_ddλ = r * theta_dot**2 - ω * r * t_dot * theta_dot
    dθ_ddλ = -2 * r_dot * theta_dot / r + (ω + r * dω) * t_dot * r_dot

    return [t_dot, r_dot, theta_dot, dt_ddλ, dr_ddλ, dθ_ddλ]

# Initial conditions
t0 = 0
r0 = 1e22
theta0 = 0
E = 1.0
L = 5e29
t_dot0 = E
theta_dot0 = L / r0**2
r_dot0 = 0

y0 = [t0, r0, theta0, t_dot0, r_dot0, theta_dot0]

sol = solve_ivp(geodesic_eq, [0, 2e16], y0, rtol=1e-9, atol=1e-10, max_step=1e13)

r = sol.y[1]
theta = sol.y[2]

x = r * np.cos(theta)
y = r * np.sin(theta)

plt.figure(figsize=(6,6))
plt.plot(x, y, lw=1.2, label="Spiralgeodet (ljus)")
plt.xlabel("x [m]")
plt.ylabel("y [m]")
plt.title("HRR-D v5.2 – Spiraliserad ljusgeodet")
plt.grid(True)
plt.axis("equal")
plt.legend()
plt.tight_layout()
plt.show()