# HRR-D v5.2 – Harmonisk Roterande Rumtids-Dynamik
Detta är den officiella versionen 5.2 av HRR-D, med spiralmetrik, dämpad ω(r) och observationella tester mot:

- Spiralgeodeter
- Supernovadata
- CMB-resonans
- Gravitationslinsning

Alla simuleringar är körbara med Python.